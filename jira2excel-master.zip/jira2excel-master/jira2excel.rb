## change the directory in which script is and execute
Dir.chdir(__dir__)

## to put out without buffering on ruby2.6.3p62 on mingw64, msys2
$stdout.sync = true

# refer company's JIRA rest api access manual
# https://www.tool.sony.biz/ElephantPortal/pages/viewpage.action?pageId=194379824
#

require 'pp'
require 'jira-ruby'
require 'win32ole'
require 'optparse'
require 'io/console'
require './config'

## check $site is defined in config.rb
unless $site
  $stderr.puts "$site is not found in config.rb!"
  exit
end

## option
options = {}
opts = OptionParser.new do |opts|
  opts.version = [0,6] # 0.X
  # 0.6 put out Severity field
  # 0.5 add software version 1,2,3
  # 0.4 add sheet "filter" have filter information same as "Manage Filters"
  #     sheet name change to "Issues"
  # 0.3 fix issue's url which missed to include "browse",
  #     fix "Resolved" to decouple date and time
  #     add ClosedDate
  # 0.2 decoupling date and time in date type fields
  # 0.1 first release doesn't have git tag
  opts.on("--filter=id","https://.../jira3/issues/?filter=179850",\
                        "e.g id 179850",\
                        Integer) {|v| options[:filterid] = v}
  opts.on("--key=id"   ,"https://.../jira3/browse/PROJECT-982",\
                        "e.g id PROJECT-982",\
                        String)  {|v| options[:keyid]    = v}
  opts.on_tail("--version", "Show version") do
    puts opts.ver
    exit
  end
end
opts.parse!(ARGV)

## filterid
#$filterid = options[:filterid] if options[:filterid]
$filterid = options[:filterid] || $filterid
# options[:filterid]&.yield_self { $filterid = _1 } Ruby 2.7

## keyeid
$keyid = options[:keyid] || $keyid

if $filterid
  if $keyid
    $stderr.puts "choose either --filter or --key!"
    $stderr.puts opts.help
    exit
  end
else
  unless $keyid
    $stderr.puts opts.help
    exit
  end
end

## user/password
$username ||= ""
until $username.length > 0
  print "username: "
  $username = STDIN.gets.chomp
end

$password ||= ""
until $password.length > 0
  print "password: "
  $password = STDIN.noecho(&:gets).chomp
end
puts # to format

# elepahnt passowrd policy, see the following url
# https://www.tool.sony.biz/ElephantPortal/pages/viewpage.action?pageId=167182338#Elephant%E7%8B%AC%E8%87%AA%E3%83%91%E3%82%B9%E3%83%AF%E3%83%BC%E3%83%89%E3%81%AE%E9%81%8B%E7%94%A8%E5%A4%89%E6%9B%B4%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6/Changeintheoperationalschemeof%22ElephantPasswords%22-Japanesetext
#
# if your passowrd is expired, go to the following url and set new passowrd.
# https://www.tool.sony.biz/CrowdManager/UserInformation
#

## JIRA::Client options
options = {
  :username           => $username ,
  :password           => $password ,
  :site               => $site,
  :context_path       => '/jira3',
  :auth_type          => :cookie,  # Use cookie based authentication
  :use_cookies        => true,     # Send cookies with each request
  :http_debug         => true,
}

$url_prefix = "#{options[:site]}#{options[:context_path]}"

client = JIRA::Client.new(options)

## jira issues attributes
# (rdb:1) pp issues[0].attrs.keys
# ["expand", "id", "self", "key", "fields"]
# (rdb:1) pp issues[0].attrs["fields"].keys
# has verious fields
$jira_ofields = { # ofields: output fields
  # Excel column title  issue[].attrs keys
  "Key"                => ["key"],
  "issuetype"          => ["fields","issuetype","name"],
  "Summary"            => ["fields","summary"],
  "Status"             => ["fields","status","name"],
  "Created"            => ["fields","created"],
  "Resolved"           => ["fields","resolutiondate"],
  "Settlement"         => ["fields","customfield_10039","value"],
  "DetectedDate"       => ["fields","customfield_10011"],
  "ClosedDate"         => ["fields","customfield_10152"],
  "JudgementDetails"   => ["fields","customfield_10301"],
  "Judgement"          => ["fields","customfield_10040","value"],
  "Defect_Rank"        => ["fields","customfield_10013","value"],
  "Severity"           => ["fields","customfield_11300","value"],
  "Frequency"          => ["fields","customfield_10023","value"],
  "FixType"            => ["fields","customfield_10030","value"],
  "DefectiveFunction"  => ["fields","customfield_10120","value"],
  "DetectedDivision"   => ["fields","customfield_13600","value"],
  "Reporter"           => ["fields","reporter","displayName"],
  "Assignee"           => ["fields","assignee","displayName"],
  "Software version 1" => ["fields","customfield_10401"],
  "Software version 2" => ["fields","customfield_10402"],
  "Software version 3" => ["fields","customfield_10403"],
}

def print_column_title_in_sheet(sheet)
  $jira_ofields.keys.each.with_index(1) do |title,col|
    sheet.rows[1].columns[col] = title
  end
end

$workbook = nil

def excel_sheet_make
  unless $workbook
    # to suppres "*** buffer overflow detected ***:" error
    # http://seesaawiki.jp/w/kou1okada/d/20180810%20-%20Cygwin%20-%20Ruby%20-%20Excel
    wsh = WIN32OLE.new('WScript.Shell')
    ["USERPROFILE", "HOMEDRIVE", "HOMEPATH"].each{|k|wsh.Environment("Process").setproperty("item", k, (["Process", "Volatile", "User", "System"].map{|t|wsh.Environment(t).Item(k)} << ENV[k]).bsearch{|x|x!=""})}

    # refer: https://qiita.com/z_yuki/items/47f05cb4694489228e0f
    excel = WIN32OLE.new('Excel.Application')
    excel.visible = true

    $workbook = excel.workbooks.add # new excel book
    $workbook.Worksheets.Item(1) # select first sheet
  else
    $workbook.Worksheets.Add
  end
end

def print_filter_attrs(sheet,filter_attrs)
  if sheet
    sheet = excel_sheet_make
    sheet.Name = "filter"
    sheet.Cells.Font.Name = "Meiryo UI"
    sheet.Cells.Font.Size = 10

    # input data into sheet cells
    filter_attrs.each.with_index(1) do |(key,val), row|
      sheet.Range("A#{row}").Value = "#{key}" # to convert string in case of key,value is not type in excel's acceptable value
      if key == :url
        sheet.Hyperlinks.Add(Anchor: sheet.Range("B#{row}"),Address: val,TextToDisplay: val)
      else
        sheet.Range("B#{row}").Value = "#{val}"
      end
    end
  end
end

def print_issues(sheet,issues)

  if sheet # in excell
    sheet = excel_sheet_make
    sheet.Name = "Issues"
    sheet.Cells.Font.Name = "Meiryo UI"
    sheet.Cells.Font.Size = 10
    print_column_title_in_sheet(sheet)
    # shoud set AutoFilter after row 1 is inputted
    sheet.Rows(1).AutoFilter unless sheet.AutoFilterMode
  end

  issues.each.with_index(2) do |issue,excel_row| # 2: for excel sheet row is 2
    # refer https://qiita.com/k_karen/items/e64ad111c63835acee07#%E7%B5%90%E8%AB%96%E6%9C%AC%E9%A0%85%E7%9B%AE%E3%82%88%E3%82%8A%E5%BE%8C%E3%81%AF%E3%83%9D%E3%82%A8%E3%83%A0%E3%81%A7%E3%81%99
    $jira_ofields.each.with_index(1) do |(key,args),excel_col| # 1: for excel sheet col is 1
      # *args https://thr3a.hatenablog.com/entry/20180613/1528867987
      val = issue.attrs.dig(*args)

      # to remove {text=[ .... ]} in "JudgementDetails" field
      val.sub!(/{text=\[(?<body>.*)\]}/m,'\k<body>') if val.class == String

      if sheet
        case key
        when "Key"
          url  = "#{$url_prefix}/browse/#{val}"
          cell = "A#{excel_row}" # fixed colmn
          sheet.Hyperlinks.Add(Anchor: sheet.Range(cell),Address: url,TextToDisplay: val)
        when "Created","Resolved","DetectedDate","ClosedDate"
          # val
          # Create/Resolved : e.g. "2020-03-24T18:25:40.000+0900"
          # DetectedDate    : e.g. "2f019-11-05" has no time info
          # even if specified %m %R, Excel doesn't put prefix '0' with its display spec.
          # ClosedDate      : may not hav vale, need to check if val is nil
          sheet.rows[excel_row].columns[excel_col] = Time.parse(val).strftime("%Y/%m/%d %R:%S") if val
        else
          sheet.rows[excel_row].columns[excel_col] = val
        end
      else
        puts "#{key}: #{val}"
      end
    end
  end

end

if $filterid
=begin
  issues = client.Filter.find(filterid).issues # this limits 50 issues
=end

  ## https://github.com/sumoheavy/jira-ruby/issues/110#issue-81017648
  filter = client.Filter.find($filterid)
  filter_attrs = {}
  filter_attrs[:url]   = filter.viewUrl
  filter_attrs[:jql]   = filter.jql
  filter_attrs[:name]  = filter.name

  displayName = filter.attrs["owner"]["displayName"]
  name        = filter.attrs["owner"]["name"]
  filter_attrs[:owner] = "#{displayName} #{name}"
  filter_attrs[:sharePermissions] = filter.sharePermissions
  # filter_attrs[:subscriptions]  = filter.subscriptions

  aggregate_issues = []
  max_results = 50
  loop do
    issues = JIRA::Resource::Issue.jql(client, filter.jql, max_results: max_results, start_at: aggregate_issues.size)
    aggregate_issues.concat issues
    break if issues.size < max_results
  end

  print_issues(sheet=true,aggregate_issues)
  print_filter_attrs(sheet=true,filter_attrs)

elsif $keyid
  issue = client.Issue.find($keyid)
  print_issues(sheet=true,Array[issue])
end

=begin
  # SK2 GM6 SQA Alexa MRM + ECIA registerd
  # jql = 'project = BISYAMON1G AND reporter in ("0000910700", 9004031776, 5109U21262, 5109U20695) AND (FixType != Cancel OR FixType = EMPTY) AND CancelType = EMPTY AND (DetectedDate >= "2018/10/15" AND DetectedDate <= "2019/03/13") AND issuetype not in (Question)'
  # HK/HK2
  # jql = 'project = 2018_HA_HK_SQA AND DetectedDate >= "2019/09/23" AND DetectedDate <= "2020/04/20" AND reporter in (5109U21197, 5109U24086, 9004033736, 9004031776, "0000910700") AND issuetype = Bug AND (FixType != Cancel OR FixType = EMPTY) AND CancelType = EMPTY ORDER BY created ASC'

  options = {
    :max_results => 10000,
    # https://github.com/sumoheavy/jira-ruby/blob/master/example.rb#L64
    #:fields      => jql_ofkv # this array is the field list which you want to select from jira issue
  }

  issues = client.Issue.jql(jql,options)
  print_issues(sheet=true,issues)
=end
